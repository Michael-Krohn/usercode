import FWCore.ParameterSet.Config as cms

from Configuration.Geometry.GeometryExtended_cff import *

