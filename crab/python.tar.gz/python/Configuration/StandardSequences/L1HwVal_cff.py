import FWCore.ParameterSet.Config as cms

from L1Trigger.Configuration.L1HwVal_cff import *

