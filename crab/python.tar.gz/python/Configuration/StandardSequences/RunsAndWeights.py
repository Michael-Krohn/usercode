RunsAndWeights = {
    'Run2012_AB_C_D_oneRunPerEra' : 'SimGeneral.Configuration.RunsAndWeights_Run2012_AB_C_D_oneRunPerEra'
    }
