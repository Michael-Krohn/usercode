import FWCore.ParameterSet.Config as cms

from IOMC.RandomEngine.IOMC_cff import *

