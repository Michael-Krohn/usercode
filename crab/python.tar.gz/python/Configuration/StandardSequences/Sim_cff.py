import FWCore.ParameterSet.Config as cms

from Configuration.StandardSequences.SimExtended_cff import *


