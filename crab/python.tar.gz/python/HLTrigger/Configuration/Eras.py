import FWCore.ParameterSet.Config as cms

def modifyHLTforEras(fragment):
    """load all Eras-based customisations for the HLT configuration"""

