import FWCore.ParameterSet.Config as cms

from SimGeneral.MixingModule.HiEventMixing_cff import *
