print """####################################################################
# WARNING: the module                                              #
# Configuration.StandardSequences.MagneticField_38T_UpdatedMap_cff #
# is deprecated. Please use                                        #
# Configuration.StandardSequences.MagneticField_cff.py             #
####################################################################"""

from Configuration.StandardSequences.MagneticField_38T_cff import *


