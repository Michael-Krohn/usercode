import FWCore.ParameterSet.Config as cms

from L1Trigger.Configuration.L1Extra_cff import *

