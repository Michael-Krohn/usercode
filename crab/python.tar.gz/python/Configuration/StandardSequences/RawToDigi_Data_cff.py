import FWCore.ParameterSet.Config as cms

from Configuration.StandardSequences.RawToDigi_cff import *


ecalDigis.DoRegional = False
#False by default ecalDigis.DoRegional = False

