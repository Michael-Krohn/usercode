import FWCore.ParameterSet.Config as cms

from SimG4Core.GFlash.GflashDigi_cfi import *
