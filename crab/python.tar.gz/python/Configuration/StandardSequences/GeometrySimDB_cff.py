import FWCore.ParameterSet.Config as cms

from Configuration.Geometry.GeometrySimDB_cff import *
