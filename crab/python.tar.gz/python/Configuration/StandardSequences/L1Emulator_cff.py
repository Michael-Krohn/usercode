import FWCore.ParameterSet.Config as cms

from Configuration.StandardSequences.SimL1Emulator_cff import *
L1Emulator = cms.Sequence(SimL1Emulator)

