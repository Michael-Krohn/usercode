EventInterpretation = {
    'top' : 'CommonTools.ParticleFlow.EITopPAG_cff',
    'MiniAODfromMiniAOD' : 'PhysicsTools.PatAlgos.slimming.MiniAODfromMiniAOD_cff'
    }
