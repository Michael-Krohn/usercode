import FWCore.ParameterSet.Config as cms

#
# Analysis sequences
#
from HiggsAnalysis.Configuration.HiggsAnalysis_cff import *
from TopQuarkAnalysis.Configuration.TopQuarkAnalysis_cff import *

