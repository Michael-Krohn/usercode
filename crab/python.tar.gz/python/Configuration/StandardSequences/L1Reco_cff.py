import FWCore.ParameterSet.Config as cms

from L1Trigger.Configuration.L1TReco_cff import *

