import FWCore.ParameterSet.Config as cms

#
# HLTrigger table
#
from Configuration.HLT.HLTtable_cff import *

