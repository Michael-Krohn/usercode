import FWCore.ParameterSet.Config as cms

from Configuration.Geometry.GeometryRecoDB_cff import *
from Configuration.Geometry.GeometrySimDB_cff import *

