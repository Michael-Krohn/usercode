import FWCore.ParameterSet.Config as cms

from SimG4Core.GFlash.GflashSim_cfi import *
