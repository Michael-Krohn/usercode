print "This file has moved to Configuration/Applications; please update"
from Configuration.Applications.cmsDriverOptions import *
