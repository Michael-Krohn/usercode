#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/Configuration/DataProcessing/',1)[0])+'/cfipython/slc6_amd64_gcc530/Configuration/DataProcessing')
