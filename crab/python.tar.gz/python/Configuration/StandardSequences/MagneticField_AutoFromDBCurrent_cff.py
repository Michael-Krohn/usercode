# This cff is obsolete and will eventually be deprecated.
# Please replace it with 
# Configuration.StandardSequences.MagneticField_cff.py
# in your setup.

from Configuration.StandardSequences.MagneticField_cff import *
